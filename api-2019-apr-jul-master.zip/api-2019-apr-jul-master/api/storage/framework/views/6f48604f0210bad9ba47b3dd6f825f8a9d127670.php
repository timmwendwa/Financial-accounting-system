<?php $__env->startSection('title', 'Staff - '); ?>

<?php $__env->startSection('staff-active', 'active'); ?>

<?php $__env->startSection('d_title', 'Staff'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header card-header-primary">
      <h4 class="card-title ">Staff</h4>
      <p class="card-category">
        Daily quote : 'jishinde ushinde..'
      </p>
    </div>
  <div class="card-body">
    <table class="table">
      <thead class=" text-primary">
        <th>Name</th>
        <th>Tel</th>
        <th>Role</th>
        <th>Hours</th>
        <th>Weekly Wage</th>
      </thead>
      <tbody>
        <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td>
                <?php echo e($s->fname); ?>

                <?php echo e($s->mname); ?>

                <?php echo e($s->lname); ?>

            </td>
            <td><?php echo e($s->tel); ?></td>
            <td><?php echo e($s->type_of_work); ?></td>
            <td><?php echo e($s->hours_per_day); ?></td>
            <td><?php echo e($s->wage_per_week); ?></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>