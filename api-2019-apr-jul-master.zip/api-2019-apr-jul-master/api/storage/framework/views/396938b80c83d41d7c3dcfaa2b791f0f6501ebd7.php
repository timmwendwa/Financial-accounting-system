<?php $__env->startSection('title', 'Cows - '); ?>

<?php $__env->startSection('cow-active', 'active'); ?>

<?php $__env->startSection('d_title', 'Cows'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header card-header-primary">
      <h4 class="card-title ">Cow</h4>
      <p class="card-category">
        Daily quote : 'jishinde ushinde..'
      </p>
    </div>
  <div class="card-body">
  <table class="table">
    <thead class=" text-primary">
      <th>Name</th>
      <th>Gender</th>
      <th>Weight(Kgs.)</th>
      <th>Age (Yrs.)</th>
    </thead>
    <tbody>
      <?php $__currentLoopData = $cows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($cow->name); ?></td>
          <td>
              <?php if($cow->gender == 0): ?>
                Male
              <?php else: ?>
                Female
              <?php endif; ?>
          </td>
          <td><?php echo e($cow->weight); ?></td>
          <td><?php echo e($cow->age); ?></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>