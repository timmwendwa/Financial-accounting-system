<?php $__env->startSection('title', 'Dashboard - '); ?>

<?php $__env->startSection('dashboard-active', 'active'); ?>

<?php $__env->startSection('d_title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
  <img width='90%' align='center' src='coming-soon.png' />
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>