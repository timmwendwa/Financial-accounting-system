@extends('layout')

{{-- page title --}}
@section('title', 'Dashboard - ')
{{-- active menu --}}
@section('dashboard-active', 'active')
{{-- Title 2 --}}
@section('d_title', 'Dashboard')
{{-- the content --}}
@section('content')
  <img width='90%' align='center' src='coming-soon.png' />
@endsection
