<?php

//phpinfo();

//this is an inbuilt function that displays all information concerning php..

$fee_balance = 200;
$name = 'Wambua';
$message = '$2name has a fee balance of $fee_balanace';
Echo($message);

?>
